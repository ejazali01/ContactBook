import React from 'react'

const Header = () => {
  return (
        <div className='ui fixed menu'>
            <div className='ui container' >
                <h2 style={{margin :'0 auto'}}>Contact Manager</h2>
            </div>
        </div>
  )
}

export default Header